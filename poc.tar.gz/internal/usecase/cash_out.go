package usecase

import (
	"errors"
	"time"

	"github.com/ishee11/poc/internal/entity"
)

type CashOutCommand struct {
	RequestID string
	SessionID entity.SessionID
	PlayerID  entity.PlayerID
	Chips     int64
}

type CashOutUseCase struct {
	opRepo      OperationRepository
	sessionRepo SessionRepository
	txManager   TxManager
	idGen       OperationIDGenerator
}

func (uc *CashOutUseCase) Execute(cmd CashOutCommand) error {
	if cmd.Chips <= 0 {
		return entity.ErrInvalidChips
	}

	return uc.txManager.RunInTx(func(tx Tx) error {
		// 1. session
		session, err := uc.sessionRepo.FindByID(tx, cmd.SessionID)
		if err != nil {
			return err
		}

		if session.Status() != entity.StatusActive {
			return entity.ErrSessionNotActive
		}

		// 2. player state
		opType, found, err := uc.opRepo.GetLastOperationType(tx, cmd.SessionID, cmd.PlayerID)
		if err != nil {
			return err
		}

		if !found {
			return entity.ErrPlayerNotInGame
		}

		if opType != entity.OperationBuyIn {
			return entity.ErrInvalidOperation
		}

		// 3. table validation (через operations!)
		sessionAggregates, err := uc.opRepo.GetSessionAggregates(tx, cmd.SessionID)
		if err != nil {
			return err
		}

		tableChips := sessionAggregates.TotalBuyIn - sessionAggregates.TotalCashOut
		if cmd.Chips > tableChips {
			return entity.ErrInvalidCashOut
		}

		// 4. создаём operation
		opID := uc.idGen.New()

		op, err := entity.NewOperation(
			opID,
			cmd.RequestID,
			cmd.SessionID,
			entity.OperationCashOut,
			cmd.PlayerID,
			cmd.Chips,
			time.Now(),
		)
		if err != nil {
			return err
		}

		// 5. сохраняем operation (идемпотентность тут)
		if err := uc.opRepo.Save(tx, op); err != nil {
			if errors.Is(err, entity.ErrDuplicateOperation) {
				return nil
			}
			return err
		}

		// 6. обновляем session cache
		if err := session.CashOut(cmd.Chips); err != nil {
			return err
		}

		// 7. сохраняем session
		if err := uc.sessionRepo.Save(tx, session); err != nil {
			return err
		}

		return nil
	})
}
