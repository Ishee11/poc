package usecase

import (
	"errors"
	"time"

	"github.com/ishee11/poc/internal/entity"
)

type OperationIDGenerator interface {
	New() entity.OperationID
}

type BuyInUseCase struct {
	opRepo      OperationRepository
	sessionRepo SessionRepository
	txManager   TxManager
	idGen       OperationIDGenerator
}

type BuyInCommand struct {
	RequestID string

	SessionID entity.SessionID
	PlayerID  entity.PlayerID
	Chips     int64
}

func NewBuyInUseCase(
	opRepo OperationRepository,
	sessionRepo SessionRepository,
	txManager TxManager,
	idGen OperationIDGenerator,
) *BuyInUseCase {
	return &BuyInUseCase{
		opRepo:      opRepo,
		sessionRepo: sessionRepo,
		txManager:   txManager,
		idGen:       idGen,
	}
}

func (uc *BuyInUseCase) Execute(cmd BuyInCommand) error {
	return uc.txManager.RunInTx(func(tx Tx) error {

		// 1. генерим ID операции (внутренний)
		opID := uc.idGen.New()

		// 2. создаём operation (ВАЖНО: сюда должен попасть RequestID — обсудим ниже)
		op, err := entity.NewOperation(
			opID,
			cmd.RequestID,
			cmd.SessionID,
			entity.OperationBuyIn,
			cmd.PlayerID,
			cmd.Chips,
			time.Now(),
		)
		if err != nil {
			return err
		}

		// ⚠️ тут важный момент — repo должен учитывать RequestID
		err = uc.opRepo.Save(tx, op /* + cmd.RequestID */)
		if err != nil {
			if errors.Is(err, entity.ErrDuplicateOperation) {
				return nil
			}
			return err
		}

		// 3. загружаем session
		session, err := uc.sessionRepo.FindByID(tx, cmd.SessionID)
		if err != nil {
			return err
		}

		// 4. бизнес-логика
		if err := session.BuyIn(cmd.Chips); err != nil {
			return err
		}

		// 5. сохраняем session
		if err := uc.sessionRepo.Save(tx, session); err != nil {
			return err
		}

		return nil
	})
}
